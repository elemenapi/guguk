#!/bin/bash

#################################
## Begin of user-editable part ##
#################################

POOL=ethash.unmineable.com:3333
WALLET=DOGE:DABNnG3N8nyUMm1wJi5Y3SqPa4tBTFcpdi.asu

#################################
##  End of user-editable part  ##
#################################

cd "$(dirname "$0")"

chmod +x gugu && ./gugu --algo ETHASH --pool $POOL --user $WALLET  --ethstratum ETHPROXY $@
